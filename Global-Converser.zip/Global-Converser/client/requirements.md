## Packages
react-markdown | To render markdown responses from the AI
react-syntax-highlighter | To highlight code blocks within markdown

## Notes
- The backend handles the AI conversation via POST /api/chat.
- Messages are displayed in a chat bubble format.
- The interface mimics ChatGPT's clean, centered layout.
