import { useState, useRef, useEffect } from "react";
import { ArrowUp, Mic, Square } from "lucide-react";
import { cn } from "@/lib/utils";
import { useVoice } from "@/hooks/use-voice";
import { useToast } from "@/hooks/use-toast";

interface ChatInputProps {
  onSend: (message: string) => void;
  disabled?: boolean;
  voiceMode?: boolean;
}

export function ChatInput({ onSend, disabled, voiceMode }: ChatInputProps) {
  const [input, setInput] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { toast } = useToast();
  const { isListening, startListening, stopListening } = useVoice({
    onTranscript: (text) => {
      if (text.trim()) {
        setInput(text);
        // Auto-send in voice mode
        if (voiceMode && text.trim()) {
          setTimeout(() => {
            onSend(text);
            setInput("");
          }, 100);
        }
      }
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Microphone Error",
        description: error,
      });
    },
  });

  // Auto-start listening in voice mode
  useEffect(() => {
    if (voiceMode && !disabled) {
      startListening();
    } else {
      stopListening();
    }
  }, [voiceMode, disabled, startListening, stopListening]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [input]);

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || disabled) return;
    onSend(input);
    setInput("");
    
    // Reset height
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const toggleMic = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  return (
    <div className="relative w-full max-w-3xl mx-auto">
      <div className={cn(
        "relative flex items-end w-full p-3 bg-card border rounded-2xl shadow-sm transition-all duration-200 focus-within:ring-2 focus-within:ring-primary/10 focus-within:border-primary/50",
        disabled && "opacity-50 cursor-not-allowed bg-muted",
        isListening && "ring-2 ring-primary/30 border-primary/50"
      )}>
        <textarea
          ref={textareaRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={isListening ? "Listening..." : "Message AI..."}
          className="w-full max-h-[200px] py-2 px-1 bg-transparent border-none resize-none focus:outline-none focus:ring-0 text-base placeholder:text-muted-foreground/70"
          rows={1}
          disabled={disabled}
        />
        
        {/* Voice button */}
        <button
          onClick={toggleMic}
          disabled={disabled}
          className={cn(
            "ml-1 p-2 rounded-xl transition-all duration-200 ease-out flex-shrink-0 mb-0.5",
            isListening
              ? "bg-red-500 text-white hover:opacity-90 hover:scale-105 active:scale-95 shadow-md animate-pulse"
              : "bg-muted text-muted-foreground hover:bg-secondary hover:text-foreground"
          )}
          title={isListening ? "Stop listening" : "Start voice input"}
          data-testid="button-voice-toggle"
        >
          {isListening ? (
            <Square className="w-5 h-5 fill-current" />
          ) : (
            <Mic className="w-5 h-5" />
          )}
        </button>

        {/* Send button */}
        <button
          onClick={() => handleSubmit()}
          disabled={!input.trim() || disabled}
          className={cn(
            "ml-1 p-2 rounded-xl transition-all duration-200 ease-out flex-shrink-0 mb-0.5",
            input.trim() && !disabled
              ? "bg-primary text-primary-foreground hover:opacity-90 hover:scale-105 active:scale-95 shadow-md" 
              : "bg-muted text-muted-foreground cursor-not-allowed"
          )}
          data-testid="button-send"
        >
          {disabled && input.trim() ? (
            <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin" />
          ) : (
            <ArrowUp className="w-5 h-5" strokeWidth={2.5} />
          )}
        </button>
      </div>
      <p className="text-xs text-center text-muted-foreground mt-3">
        AI can make mistakes. Consider checking important information.
      </p>
    </div>
  );
}
