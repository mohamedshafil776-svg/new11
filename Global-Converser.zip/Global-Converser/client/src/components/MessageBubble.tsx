import { Bot, User, Copy, Check, Volume2, Pause } from "lucide-react";
import { cn } from "@/lib/utils";
import ReactMarkdown from "react-markdown";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { oneDark } from "react-syntax-highlighter/dist/esm/styles/prism";
import { useState, useEffect } from "react";
import { useVoice } from "@/hooks/use-voice";
import type { ChatMessage } from "@/hooks/use-chat";

interface MessageBubbleProps {
  message: ChatMessage;
}

export function MessageBubble({ message }: MessageBubbleProps) {
  const isUser = message.role === "user";
  const [copied, setCopied] = useState(false);
  const { isSpeaking, speak, stopSpeaking } = useVoice();

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSpeak = () => {
    if (isSpeaking) {
      stopSpeaking();
    } else {
      speak(message.content);
    }
  };

  return (
    <div className={cn(
      "group flex gap-4 md:gap-6 w-full max-w-3xl mx-auto py-6 md:py-8 px-4",
      isUser ? "flex-row-reverse" : "flex-row"
    )}>
      {/* Avatar */}
      <div className={cn(
        "flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center border shadow-sm",
        isUser 
          ? "bg-primary text-primary-foreground border-primary" 
          : "bg-background text-primary border-border"
      )}>
        {isUser ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
      </div>

      {/* Content */}
      <div className={cn(
        "relative flex-1 overflow-hidden",
        isUser ? "text-right" : "text-left"
      )}>
        <div className={cn(
          "prose prose-neutral dark:prose-invert max-w-none break-words leading-7",
          isUser && "bg-secondary/50 inline-block py-2.5 px-5 rounded-2xl rounded-tr-sm text-secondary-foreground text-left"
        )}>
          {isUser ? (
            <div className="whitespace-pre-wrap">{message.content}</div>
          ) : (
            <ReactMarkdown
              components={{
                code({ node, inline, className, children, ...props }: any) {
                  const match = /language-(\w+)/.exec(className || "");
                  return !inline && match ? (
                    <SyntaxHighlighter
                      {...props}
                      style={oneDark}
                      language={match[1]}
                      PreTag="div"
                      customStyle={{
                        margin: 0,
                        borderRadius: "0.5rem",
                        background: "hsl(var(--secondary))",
                      }}
                    >
                      {String(children).replace(/\n$/, "")}
                    </SyntaxHighlighter>
                  ) : (
                    <code className={className} {...props}>
                      {children}
                    </code>
                  );
                },
              }}
            >
              {message.content}
            </ReactMarkdown>
          )}
        </div>

        {/* Action buttons (Assistant only) */}
        {!isUser && !message.isError && (
          <div className="flex items-center gap-2 mt-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
            <button
              onClick={handleSpeak}
              className={cn(
                "p-1.5 rounded-md transition-colors",
                isSpeaking
                  ? "text-red-500 bg-red-500/10"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary"
              )}
              title={isSpeaking ? "Stop speaking" : "Listen to response"}
              data-testid="button-speak"
            >
              {isSpeaking ? <Pause className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
            <button
              onClick={handleCopy}
              className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-secondary rounded-md transition-colors"
              title="Copy to clipboard"
              data-testid="button-copy"
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
