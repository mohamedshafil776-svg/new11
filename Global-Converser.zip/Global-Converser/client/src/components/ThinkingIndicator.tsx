import { Bot } from "lucide-react";

export function ThinkingIndicator() {
  return (
    <div className="flex gap-4 md:gap-6 w-full max-w-3xl mx-auto py-6 px-4 animate-in fade-in duration-300">
      <div className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center border shadow-sm bg-background text-primary border-border">
        <Bot className="w-5 h-5" />
      </div>
      <div className="flex items-center gap-1.5 py-2.5">
        <div className="w-2 h-2 rounded-full bg-primary/40 animate-bounce [animation-delay:-0.3s]"></div>
        <div className="w-2 h-2 rounded-full bg-primary/40 animate-bounce [animation-delay:-0.15s]"></div>
        <div className="w-2 h-2 rounded-full bg-primary/40 animate-bounce"></div>
      </div>
    </div>
  );
}
