import { useMutation } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { type Message } from "@shared/schema";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

// We define a local message type that includes temporary loading states or error states if needed
export type ChatMessage = {
  role: "user" | "assistant";
  content: string;
  isError?: boolean;
};

export function useChat() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const { toast } = useToast();

  const mutation = useMutation({
    mutationFn: async (message: string) => {
      const res = await fetch(api.chat.message.path, {
        method: api.chat.message.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message }),
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to send message");
      }

      return api.chat.message.responses[200].parse(await res.json());
    },
    onMutate: async (newMessage) => {
      // Optimistically add user message
      setMessages((prev) => [
        ...prev,
        { role: "user", content: newMessage },
      ]);
    },
    onSuccess: (data) => {
      // Add AI response
      setMessages((prev) => [
        ...prev,
        { role: "assistant" as const, content: data.content },
      ]);
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error sending message",
        description: error.message,
      });
      
      // Optionally add an error message to the chat flow
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "Sorry, I encountered an error processing your request.", isError: true },
      ]);
    },
  });

  const sendMessage = (message: string) => {
    mutation.mutate(message);
  };

  const clearChat = () => {
    setMessages([]);
  };

  return {
    messages,
    sendMessage,
    clearChat,
    isPending: mutation.isPending,
  };
}
