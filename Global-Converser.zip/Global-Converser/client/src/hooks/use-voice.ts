import { useState, useRef, useCallback } from "react";

interface UseVoiceProps {
  onTranscript?: (text: string) => void;
  onError?: (error: string) => void;
}

export function useVoice({ onTranscript, onError }: UseVoiceProps = {}) {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const recognitionRef = useRef<any>(null);

  // Initialize speech recognition
  const initRecognition = useCallback(() => {
    if (recognitionRef.current) return;

    const SpeechRecognition = window.webkitSpeechRecognition || (window as any).SpeechRecognition;
    
    if (!SpeechRecognition) {
      onError?.("Speech Recognition not supported in your browser");
      return false;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.language = "en-US";

    let transcript = "";

    recognition.onstart = () => {
      setIsListening(true);
      transcript = "";
    };

    recognition.onresult = (event: any) => {
      transcript = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcriptSegment = event.results[i][0].transcript;
        transcript += transcriptSegment;
      }

      // Only call callback on final result
      if (event.results[event.results.length - 1].isFinal) {
        onTranscript?.(transcript);
      }
    };

    recognition.onerror = (event: any) => {
      onError?.(event.error);
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current = recognition;
    return true;
  }, [onTranscript, onError]);

  // Start listening
  const startListening = useCallback(() => {
    if (!initRecognition()) return;
    recognitionRef.current?.start();
  }, [initRecognition]);

  // Stop listening
  const stopListening = useCallback(() => {
    recognitionRef.current?.stop();
    setIsListening(false);
  }, []);

  // Speak text
  const speak = useCallback((text: string) => {
    if (!("speechSynthesis" in window)) {
      onError?.("Text-to-Speech not supported in your browser");
      return;
    }

    // Cancel any ongoing speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1;
    utterance.pitch = 1;
    utterance.volume = 1;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  }, [onError]);

  // Stop speaking
  const stopSpeaking = useCallback(() => {
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  }, []);

  return {
    isListening,
    isSpeaking,
    startListening,
    stopListening,
    speak,
    stopSpeaking,
  };
}
