import { useEffect, useRef, useState } from "react";
import { useChat } from "@/hooks/use-chat";
import { useVoice } from "@/hooks/use-voice";
import { ChatInput } from "@/components/ChatInput";
import { MessageBubble } from "@/components/MessageBubble";
import { ThinkingIndicator } from "@/components/ThinkingIndicator";
import { Sparkles, Mic, X } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Chat() {
  const { messages, sendMessage, isPending } = useChat();
  const bottomRef = useRef<HTMLDivElement>(null);
  const [voiceMode, setVoiceMode] = useState(false);
  const { speak } = useVoice();

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isPending]);

  // Auto-speak the last AI message when in voice mode
  useEffect(() => {
    if (voiceMode && messages.length > 0) {
      const lastMessage = messages[messages.length - 1];
      if (lastMessage.role === "assistant" && !isPending) {
        // Small delay to avoid speaking while still thinking
        setTimeout(() => {
          speak(lastMessage.content);
        }, 500);
      }
    }
  }, [messages, voiceMode, isPending, speak]);

  return (
    <div className="flex flex-col h-screen bg-background text-foreground">
      {/* Header */}
      <header className={cn(
        "sticky top-0 z-10 w-full glass-panel px-4 py-3 flex items-center justify-between transition-all duration-300",
        voiceMode && "bg-red-500/10 border-b border-red-500/20"
      )}>
        <div className="flex items-center gap-2 font-semibold text-lg tracking-tight">
          <div className={cn(
            "p-1.5 rounded-lg shadow-sm",
            voiceMode 
              ? "bg-red-500 text-white animate-pulse" 
              : "bg-primary text-primary-foreground"
          )}>
            {voiceMode ? <Mic className="w-5 h-5" /> : <Sparkles className="w-5 h-5" />}
          </div>
          <span>{voiceMode ? "Voice Mode Active" : "AI Assistant"}</span>
        </div>
        <div className="flex items-center gap-3">
          {voiceMode && (
            <button
              onClick={() => setVoiceMode(false)}
              className="p-2 hover:bg-red-500/20 rounded-lg transition-colors text-red-500"
              title="Exit voice mode"
              data-testid="button-exit-voice"
            >
              <X className="w-5 h-5" />
            </button>
          )}
          <div className="text-sm text-muted-foreground hidden sm:block">
            Powered by Replit AI
          </div>
        </div>
      </header>

      {/* Messages Area */}
      <main className="flex-1 overflow-y-auto w-full">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center p-8 text-center animate-in fade-in zoom-in-95 duration-500">
            <div className="bg-secondary/50 p-6 rounded-full mb-6 ring-1 ring-border shadow-lg">
              <Sparkles className="w-12 h-12 text-primary" />
            </div>
            <h1 className="text-3xl md:text-4xl font-bold mb-4 tracking-tight">
              How can I help you today?
            </h1>
            <p className="text-muted-foreground max-w-md text-lg leading-relaxed">
              Ask me anything! I can help with coding, writing, analysis, or just have a friendly chat in any language.
            </p>
            
            <button
              onClick={() => setVoiceMode(true)}
              className="mt-8 px-8 py-4 bg-red-500 hover:bg-red-600 text-white font-semibold rounded-2xl shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-105 active:scale-95 flex items-center gap-3 mx-auto mb-8"
              data-testid="button-talk-with-me"
            >
              <Mic className="w-6 h-6" />
              <span>Talk with Me</span>
            </button>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-2xl">
              {[
                "Explain quantum computing in simple terms",
                "Write a Python script to scrape a website",
                "Draft a professional email to my boss",
                "Help me debug this React component"
              ].map((suggestion, i) => (
                <button
                  key={i}
                  onClick={() => sendMessage(suggestion)}
                  className="text-left p-4 rounded-xl border bg-card hover:bg-secondary/50 hover:border-primary/20 transition-all duration-200 shadow-sm hover:shadow-md group"
                >
                  <span className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">
                    {suggestion}
                  </span>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex flex-col py-4 min-h-full">
            {messages.map((msg, idx) => (
              <MessageBubble key={idx} message={msg} />
            ))}
            {isPending && <ThinkingIndicator />}
            <div ref={bottomRef} className="h-4" />
          </div>
        )}
      </main>

      {/* Input Area */}
      <div className="w-full bg-gradient-to-t from-background via-background to-transparent pt-10 pb-6 px-4 z-10">
        <ChatInput onSend={sendMessage} disabled={isPending} voiceMode={voiceMode} />
      </div>
    </div>
  );
}
