import type { Express, Request, Response } from "express";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

// Store conversation history in memory for this session
const conversationHistory: Array<{ role: "user" | "assistant"; content: string }> = [];

// Detect language of text using simple heuristics
function detectLanguage(text: string): string {
  const langPatterns: Record<string, RegExp> = {
    es: /\b(hola|adiós|sí|no|por favor|gracias|tú|qué|dónde|cuándo|cómo|por|para|con)\b/i,
    fr: /\b(bonjour|salut|oui|non|merci|s'il vous plaît|tu|qu'|où|quand|comment|avec|pour)\b/i,
    de: /\b(hallo|ja|nein|danke|bitte|du|was|wo|wann|wie|mit|für)\b/i,
    pt: /\b(oi|olá|sim|não|obrigado|por favor|você|o quê|onde|quando|como|com|para)\b/i,
    it: /\b(ciao|sì|no|grazie|per favore|tu|cosa|dove|quando|come|con|per)\b/i,
    ru: /[а-яА-ЯёЁ]/,
    zh: /[\u4e00-\u9fff]/,
    ja: /[\u3040-\u309f\u30a0-\u30ff]/,
    ko: /[\uac00-\ud7af]/,
    ar: /[\u0600-\u06ff]/,
    hi: /[\u0900-\u097f]/,
  };

  for (const [lang, pattern] of Object.entries(langPatterns)) {
    if (pattern.test(text)) {
      return lang;
    }
  }

  return "en"; // Default to English
}

export function registerChatRoutes(app: Express): void {
  // Chat endpoint - send message and get AI response
  app.post("/api/chat", async (req: Request, res: Response) => {
    try {
      const { message } = req.body;

      if (!message) {
        return res.status(400).json({ error: "Message is required" });
      }

      // Detect language of user message
      const detectedLang = detectLanguage(message);

      // Add user message to history
      conversationHistory.push({ role: "user", content: message });

      // Language names for system message
      const languageNames: Record<string, string> = {
        es: "Spanish",
        fr: "French",
        de: "German",
        pt: "Portuguese",
        it: "Italian",
        ru: "Russian",
        zh: "Chinese",
        ja: "Japanese",
        ko: "Korean",
        ar: "Arabic",
        hi: "Hindi",
        en: "English",
      };

      const langName = languageNames[detectedLang] || "the user's language";

      // Build messages with language instruction
      const messages = [
        {
          role: "system" as const,
          content: `You are a helpful AI assistant. The user is communicating with you in ${langName}. Always respond in ${langName}, matching the language of the user's questions and statements. If the user switches languages, respond in their new language. Be natural and conversational.`,
        },
        ...conversationHistory,
      ];

      // Get response from OpenAI
      const completion = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: messages,
        max_completion_tokens: 2048,
      });

      const assistantMessage =
        completion.choices[0]?.message?.content || "I couldn't generate a response.";

      // Add assistant response to history
      conversationHistory.push({ role: "assistant", content: assistantMessage });

      res.json({
        role: "assistant",
        content: assistantMessage,
      });
    } catch (error) {
      console.error("Error in chat:", error);
      res.status(500).json({ error: "Failed to process message" });
    }
  });

  // Clear chat history
  app.post("/api/chat/clear", async (req: Request, res: Response) => {
    try {
      conversationHistory.length = 0;
      res.json({ message: "Chat cleared" });
    } catch (error) {
      console.error("Error clearing chat:", error);
      res.status(500).json({ error: "Failed to clear chat" });
    }
  });
}
