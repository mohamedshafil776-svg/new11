import { z } from "zod";

export const api = {
  chat: {
    message: {
      method: "POST" as const,
      path: "/api/chat",
      input: z.object({
        message: z.string().min(1, "Message cannot be empty"),
      }),
      responses: {
        200: z.object({
          role: z.string(),
          content: z.string(),
        }),
        400: z.object({
          error: z.string(),
        }),
        500: z.object({
          error: z.string(),
        }),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
